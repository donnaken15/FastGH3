add file in queenbee as: scripts\guitar\guitar_solo.qb

replace GuitarEvent_HitNotes in guitar_events.qb with the script in here
make sure you're replacing the script with the plural (yes, there's two scripts named this)