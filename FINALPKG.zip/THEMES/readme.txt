global.pak.xen/zones belong in folders here. To apply to the mod, drag it into __changePAK.bat.
zip/tex/gfx(+scn) belong in this folder. Drag these into __changeTEX.bat.

To save the default zones and revert to it, copy
zones to a new folder in here and name it GH3Default.